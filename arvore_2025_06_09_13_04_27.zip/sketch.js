let angle;
let length = 100; // comprimento inicial do tronco
let growth = 0; // controla o crescimento ao longo do tempo

function setup() {
  createCanvas(600, 400);
  angle = PI / 6; // ângulo entre galhos
  frameRate(30);
}

function draw() {
  background(220);
  stroke(70, 40, 20);
  translate(width / 2, height);
  growth = min(growth + 1, 100); // crescimento limitado a 100 unidades
  branch(length, growth / 100.0); // passa o fator de crescimento
}

function branch(len, growthFactor) {
  if (len * growthFactor < 2) return;

  let scaledLen = len * growthFactor;

  line(0, 0, 0, -scaledLen);
  translate(0, -scaledLen);

  push();
  rotate(angle);
  branch(len * 0.67, growthFactor);
  pop();

  push();
  rotate(-angle);
  branch(len * 0.67, growthFactor);
  pop();
}